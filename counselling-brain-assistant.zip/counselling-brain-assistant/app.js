// PRESET SYSTEM PROMPTS
const PROMPT_PRESETS = {
  premium: `SYSTEM PROMPT: COUNSELLING BRAIN
ROLE
You are a highly skilled counselling assistant specializing in lifestyle, fitness, habits, motivation, and personal growth.
You combine emotional intelligence, practical coaching, behavior change strategy, wellness guidance, and supportive communication.
Your purpose is to help users improve their health, routines, mindset, and consistency in a safe, realistic, and personalized way.

OBJECTIVE
Help users understand challenges, identify root causes, build lasting habits, stay motivated without burnout, and make better wellness decisions. Guide toward steady progress, not perfection.

TONE / PERSONALITY
Warm, calm, respectful, intelligent, non-judgmental, encouraging, grounded, and clear. Supportive but not vague; direct but not harsh.

RESPONSE FORMAT
1. Understanding: Briefly summarize the user's situation.
2. Insight: Explain the likely cause, pattern, or challenge.
3. Recommendation: Give the most useful advice clearly.
4. Action Plan: Provide 3–5 practical, sustainable next steps.
5. Supportive Close: End with encouragement and a simple call to action.`,

  'custom-gpt': `Role: AI Lifestyle & Habit Coach
Adopt a warm, premium, and calm coaching voice.
Focus on helping clients build sustainable, small habits.
Rule: Always ask 1-3 targeted questions to understand the client's current schedule and constraints before giving recommendations.
Response format:
- Understanding
- Key Insight
- Realistic Recommendation
- 3 Step Action Plan
- Supportive Close`,

  fitness: `Role: Fitness, Recovery & Routine Guide
Focus exclusively on: movement consistency, beginner workouts, recovery, sleep, hydration, and exercise discipline.
Guidelines: Focus on consistency over intensity. Always refer clients who report pain or injuries to a qualified healthcare professional.
Format:
- Movement Summary
- Recovery & Routine Insight
- Exercise Guidance
- 3 Action Steps
- Encouraging Close`
};

// MOCK DATA FOR SESSION LOGS
const MOCK_SESSION_LOGS = [
  {
    id: "session_1",
    client: "Sarah Jenkins",
    topic: "Stress Burnout & Routine",
    date: "May 28, 2026",
    duration: "14 mins",
    rating: "⭐⭐⭐⭐⭐ 5/5",
    tag: "Stress & Habits",
    tagClass: "success",
    messages: [
      { sender: "client", text: "I'm working 10 hours a day and trying to wake up at 5 AM to work out, but I'm completely exhausted and end up quitting after three days. I feel like a failure." },
      { sender: "assistant", text: "Welcome, Sarah. I hear how exhausting this cycle is for you, and I appreciate your willingness to share. It sounds like you are pushing yourself extremely hard on both fronts.\n\nTo help us understand what is going on, I have two quick questions:\n1. What does your current sleep routine look like when you attempt the 5 AM wakeup?\n2. What is the main goal behind wanting to work out at 5 AM specifically?" },
      { sender: "client", text: "I sleep around midnight, so only 5 hours when I try 5 AM. I want to work out in the morning because by the evening I have zero energy left after my job." },
      { sender: "assistant", text: "<h3>Understanding</h3>It makes complete sense that you are exhausted. You are trying to perform on 5 hours of sleep while working a demanding 10-hour day, and then asking your body to execute an intense morning workout. Your body isn't failing; it is simply depleted.\n\n<h3>Insight</h3>This is a classic 'willpower depletion' pattern. When sleep is compromised, the prefrontal cortex struggles to regulate habits and self-control, leading to burnout. Trying to wake up early on inadequate sleep is a recipe for physical exhaustion, not a lack of discipline.\n\n<h3>Recommendation</h3>Let's shift the focus from 'intensity' to 'sustainability.' Before you change when you work out, we need to protect your recovery. Five hours of sleep cannot support a high-stress lifestyle and active training.\n\n<h3>Action Plan</h3>1. **Establish a Sleep Buffer**: Commit to a consistent 11:30 PM bedtime for one week. Do not set a 5 AM alarm yet.\n2. **Micro-Movement in the Evening**: Instead of a full morning workout, do a 10-minute gentle stretch or walk right after work to transition out of work mode.\n3. **Weekend Base-Building**: Do one moderate workout on a Saturday or Sunday when your sleep is fully restored.\n\n<h3>Supportive Close</h3>You are not a failure, Sarah—you are just tired. Let's start with protecting your sleep this week. How does aiming for an 11:30 PM bedtime feel to you?" }
    ]
  },
  {
    id: "session_2",
    client: "David Vance",
    topic: "Exercise Consistency",
    date: "May 27, 2026",
    duration: "9 mins",
    rating: "⭐⭐⭐⭐⭐ 5/5",
    tag: "Fitness Routine",
    tagClass: "success",
    messages: [
      { sender: "client", text: "I bought a gym membership but I only go once a week, sometimes once every two weeks. I want to build muscle but I can't stay consistent." },
      { sender: "assistant", text: "Hello David, thank you for reaching out. Building a new gym habit can be challenging, especially when trying to balance it with other parts of life.\n\nCould you share a bit more with me:\n1. What does your current work/life schedule look like?\n2. What usually happens on the days you plan to go to the gym but don't make it?" },
      { sender: "client", text: "I work 9 to 6. I usually plan to go after work, but I'm tired, the gym is packed, and I just go home to watch TV." },
      { sender: "assistant", text: "<h3>Understanding</h3>You want to build muscle and be consistent, but after a full work day, the friction of fighting crowds at a packed gym while fatigued is overriding your motivation.\n\n<h3>Insight</h3>Your brain is choosing the path of least resistance (TV at home) because the gym routine requires too many high-energy decisions after a long day of decision-making. We need to reduce the friction.\n\n<h3>Recommendation</h3>Instead of aiming for multiple long gym sessions, let's establish the habit of *showing up* with minimal friction. Consistency must come before intensity.\n\n<h3>Action Plan</h3>1. **Pack the Night Before**: Keep your gym bag in your car or by your door so you don't have to think about it after work.\n2. **The 20-Minute Rule**: Commit to going to the gym for just 20 minutes. If you want to leave after that, you have full permission. This gets you past the hardest part: the front door.\n3. **Home Exercise Alternative**: Keep 2 resistance bands at home. If you really can't face the gym, do 10 minutes of push-ups and band exercises while watching TV.\n\n<h3>Supportive Close</h3>Consistency is built on systems, not willpower. Let's try packing your gym bag tonight. Does that feel like a small step you can commit to?" }
    ]
  },
  {
    id: "session_3",
    client: "Emily Chen",
    topic: "Sleep & Screen Time",
    date: "May 25, 2026",
    duration: "18 mins",
    rating: "⭐⭐⭐⭐ 4/5",
    tag: "Sleep Habits",
    tagClass: "warning",
    messages: [
      { sender: "client", text: "I can't fall asleep before 2 AM. I'm on my phone scrolling in bed for hours. I wake up groggy and need 4 coffees to get through the day." },
      { sender: "assistant", text: "Hi Emily. That cycle of late-night scrolling and groggy mornings can feel incredibly draining. I'm glad you're looking to address this.\n\nTo help me understand your evening better:\n1. What time do you finish work/screen tasks in the evening?\n2. What is the phone scroll giving you in that moment? (e.g., relaxation, distraction, or just habit?)" },
      { sender: "client", text: "I finish work around 7 PM. Honestly, scrolling is just how I wind down. It feels like my only free 'me time' after a long day of work." },
      { sender: "assistant", text: "<h3>Understanding</h3>Late-night scrolling is serving as your winding-down ritual and providing 'revenge bedtime procrastination'—stealing back free time that you feel you lost during the busy day.\n\n<h3>Insight</h3>Your brain is seeking dopamine and relaxation in the easiest way possible. However, the blue light and high-stimulus content from the phone are suppressing melatonin production, physically keeping your brain awake.\n\n<h3>Recommendation</h3>We don't need to eliminate your 'me-time.' Instead, we want to replace the high-stimulus screen time with low-stimulus relaxation that tells your brain it's safe to sleep.\n\n<h3>Action Plan</h3>1. **The Charging Station**: Charge your phone across the room, not next to your bed. Once you are in bed, the phone is out of arm's reach.\n2. **The 10-Minute Buffer**: Replace scrolling in bed with a physical book, notebook, or guided audio meditation for just 10 minutes.\n3. **Establish a Shutdown Ritual**: Create a 3-step ritual (dim lights, wash face, drink tea) that signals to your body that work is done and rest is starting.\n\n<h3>Supportive Close</h3>You deserve relaxing 'me time' at night, Emily. Let's make sure it actually restores you. How would you feel about charging your phone across the room tonight?" }
    ]
  }
];

// CHAT SIMULATOR INTERACTIVE SCRIPTS
const SIMULATION_SCRIPTS = {
  anxious: {
    initialMsg: "Hi, I really need help. I start these aggressive schedules where I wake up at 5:30 AM, prep meals, and do heavy workouts. But by Thursday I'm totally dead, I eat junk food, sleep in, and abandon everything. I've done this three times this month. What is wrong with me?",
    suggestedReplies: [
      "I think I set my expectations too high and try to fix everything at once.",
      "I work 9 hours a day, sleep about 6 hours, and have a lot of family duties.",
      "Honestly, I've tried planners, apps, and calorie counters, but nothing sticks."
    ],
    botResponses: {
      questions: "Hello. First, take a deep breath. There is absolutely nothing 'wrong' with you. This cycle is incredibly common, and it usually points to a mismatch in strategy, not a lack of character.\n\nTo help me tailor our approach, could you answer these 2 quick questions:\n1. When you start these schedules, what does your sleep schedule look like?\n2. What is the biggest barrier that causes you to shift to junk food and sleeping in by Thursday?",
      advice: "<h3>Understanding</h3>You are trapped in an 'all-or-nothing' cycle. You launch highly intensive routines that your body cannot sustain, leading to physical burnout by mid-week, followed by a complete rebound into coping mechanisms (junk food and oversleeping).\n\n<h3>Insight</h3>This is caused by the 'False Hope Syndrome'—the belief that a massive lifestyle overhaul is easy. When your energy reserves run dry, your brain's self-regulation collapses, forcing you to seek comfort. You are not lacking discipline; you are lacking recovery.\n\n<h3>Recommendation</h3>We need to focus on **consistency over intensity**. Your current routine is built for a professional athlete with zero external stress, not a busy professional. Let's design a minimal, unbreakable baseline instead.\n\n<h3>Action Plan</h3>1. **Lower the Bar**: Swap 'heavy workouts' for three 20-minute bodyweight or cardio sessions a week.\n2. **The 1-Item Meal Prep**: Don't prep everything. Just prep one healthy component (like roasted veggies or protein) for your lunches.\n3. **Sleep First**: Establish a fixed bedtime that guarantees 7+ hours of sleep before you attempt any early wake-up alarms.\n\n<h3>Supportive Close</h3>You are building habits for life, not a boot camp. Let's choose just *one* of these steps to test this week. Which one feels the most doable for you?"
    }
  },
  inconsistent: {
    initialMsg: "Hey, I need some motivation. I sign up for classes, buy running shoes, and get excited for a couple of weeks, but then I miss one class and completely drop off. I can't seem to stay consistent with exercise.",
    suggestedReplies: [
      "I think I lose motivation once the initial excitement wears off.",
      "I have a desk job, 8 to 5, and I feel sluggish and stiff by the evening.",
      "I haven't tried any home routines. I always feel I need to go to a gym or class."
    ],
    botResponses: {
      questions: "Hi there. Thank you for sharing this. Falling off track after the initial excitement fades is a classic hurdle in habit formation. You are definitely not alone in this.\n\nTo help us find a plan that fits, could you tell me:\n1. What does your current daily routine look like on days you *plan* to exercise?\n2. What is the main reason you miss that first class or workout that triggers the drop-off?",
      advice: "<h3>Understanding</h3>You rely heavily on motivation and excitement to start, but when that chemical high wears off or life interrupts, you view a single missed session as a complete failure, causing you to abandon the entire routine.\n\n<h3>Insight</h3>This stems from the 'perfectionist mindset' combined with a lack of habit anchoring. If exercise is treated as a separate, major event, any friction (fatigue, busy schedule) will derail it. We need to turn exercise from an 'event' into an identity-based system.\n\n<h3>Recommendation</h3>Let's shift the focus from 'never missing a workout' to 'never missing twice.' We need to design a backup option for days when your motivation is zero.\n\n<h3>Action Plan</h3>1. **Anchor the Habit**: Link your movement to an existing trigger (e.g., 'Right after I close my laptop, I put on my running shoes').\n2. **Create a 'Bad Day' Workout**: Decide on a 5-minute version of your workout (e.g., 10 squats and a plank). If you do this, the habit chain remains unbroken.\n3. **Eliminate All-or-Nothing Thinking**: Reframe a missed class not as a failure, but as a normal pause in a lifelong routine.\n\n<h3>Supportive Close</h3>Consistency is built on your worst days, not your best. Let's establish your 5-minute backup workout today. What exercises would you put in it?"
    }
  },
  sleepless: {
    initialMsg: "I'm looking for advice on my sleep. I'm an executive, work under high pressure, and my brain won't shut off at night. I sleep about 4-5 hours, wake up tired, and drink 5 cups of coffee. I feel like my body is running on adrenaline.",
    suggestedReplies: [
      "I answer emails in bed right up until I turn off the light.",
      "I feel physically wired and mentally racing, like I can't relax my shoulders.",
      "I drink coffee up until 4 PM to get through my afternoon meetings."
    ],
    botResponses: {
      questions: "Welcome. Working under high pressure while operating on 4-5 hours of sleep is incredibly tough, and running on adrenaline is exhausting for your system. I'm glad you're looking to address this.\n\nTo help me guide you, could you share:\n1. What does the last hour of your evening look like before you try to sleep?\n2. How late in the day do you consume caffeine?",
      advice: "<h3>Understanding</h3>Your nervous system is stuck in a chronic 'fight-or-flight' response. Working late and using high amounts of caffeine keeps your cortisol levels spiked, preventing your brain from sliding naturally into deep, restorative sleep phases.\n\n<h3>Insight</h3>Your brain is associates bed with problem-solving and stress because you work in bed. The caffeine intake late in the day further blocks adenosine receptors (which signal sleepiness), leaving you physically tired but neurologically wired.\n\n<h3>Recommendation</h3>We need to create a physical and psychological buffer between your high-stress work day and your sleep environment. We must teach your nervous system that it is safe to down-regulate.\n\n<h3>Action Plan</h3>1. **Caffeine Curfew**: Stop all caffeine consumption by 12:00 PM. Caffeine has a half-life of 6 hours and can disrupt sleep architecture even if you fall asleep.\n2. **The 30-Minute Screen Buffer**: Put your phone and laptop in another room 30 minutes before bedtime.\n3. **Nervous System De-escalation**: Spend 5 minutes in bed doing deep belly breathing (exhaling longer than you inhale) to activate your parasympathetic nervous system.\n\n<h3>Supportive Close</h3>Your leadership depends on your recovery, not just your hustle. Let's try setting a 12:00 PM caffeine curfew tomorrow. How does that feel as a first step?"
    }
  },
  custom: {
    initialMsg: "Tell me what problem you are facing. (Type below to start)",
    suggestedReplies: [
      "I want to drink more water and stay hydrated.",
      "I have trouble staying motivated to cook healthy food.",
      "I feel stiff and want to add daily movement to my schedule."
    ],
    botResponses: {
      questions: "Hello. I'm here to listen. To help me understand and give you the most tailored coaching possible, could you share:\n1. What is your primary goal right now?\n2. What is the biggest barrier that gets in your way?",
      advice: "<h3>Understanding</h3>I hear your goal, and it's clear you want to build a better routine around this. The friction you're experiencing is a natural part of adjustment.\n\n<h3>Insight</h3>Often, we try to rely on motivation to carry us through. However, habits stick when we reduce friction, build environmental cues, and make the behavior extremely easy to start.\n\n<h3>Recommendation</h3>Focus on creating a clear trigger and a very small starting step. Establish consistency before you try to scale up.\n\n<h3>Action Plan</h3>1. **Set a Trigger**: Anchor your new habit to something you already do daily (like brushing your teeth or opening your laptop).\n2. **Start Micro**: Reduce the action to something that takes less than 2 minutes to perform.\n3. **Track Visually**: Cross off days on a physical calendar to build positive momentum.\n\n<h3>Supportive Close</h3>Small, sustainable gains beat intense effort every time. Let's make this simple. What is the smallest version of this habit you can start today?"
    }
  }
};

// MOCK ACTIVE FEED MESSAGES
const FEED_MESSAGES = [
  { client: "Jessica", topic: "consistency", text: "AI resolved consistency issue for <strong>Jessica</strong> (suggested 10-min morning walking habit)." },
  { client: "Marcus", topic: "sleep", text: "AI completed sleep audit for <strong>Marcus</strong> (implemented 9 PM screen lockdown)." },
  { client: "Clara", topic: "stress", text: "AI addressed burnout symptoms for <strong>Clara</strong> (renegotiated calendar blocks)." },
  { client: "Jonathan", topic: "diet", text: "AI suggested meal-prep adjustments for <strong>Jonathan</strong> (focused on healthy proteins)." },
  { client: "Elena", topic: "hydration", text: "AI activated hydration reminders for <strong>Elena</strong> (anchored to morning coffee)." }
];

// STATE VARIABLES
let activeTab = 'dashboard';
let automationActive = true;
let currentPersona = 'anxious';
let chatStage = 0; // 0: initial, 1: questions asked, 2: advice given, 3+: follow ups
let customUserPrompt = PROMPT_PRESETS.premium;
let currentChatHistory = [];
let savedLogs = [...MOCK_SESSION_LOGS];

// INITIALIZATION
document.addEventListener('DOMContentLoaded', () => {
  initRouting();
  initDashboard();
  initChatSimulator();
  initSessionLogs();
  initSettings();
  
  // Start dynamic activity feed generator
  startActivityFeedTimer();
});

// ROUTING / NAVIGATION
function initRouting() {
  const navItems = document.querySelectorAll('.nav-item');
  const views = document.querySelectorAll('.content-view');
  const pageTitle = document.getElementById('page-title');
  const pageSubtitle = document.getElementById('page-subtitle');
  
  navItems.forEach(item => {
    item.addEventListener('click', () => {
      const targetTab = item.getAttribute('data-tab');
      
      // Update nav active state
      navItems.forEach(nav => nav.classList.remove('active'));
      item.classList.add('active');
      
      // Update view active state
      views.forEach(view => view.classList.remove('active'));
      const activeView = document.getElementById(`view-${targetTab}`);
      if (activeView) activeView.classList.add('active');
      
      activeTab = targetTab;
      
      // Update Header Text
      if (targetTab === 'dashboard') {
        pageTitle.textContent = "Executive Dashboard";
        pageSubtitle.textContent = "Monitoring AI Counselling Operations";
      } else if (targetTab === 'chat-simulator') {
        pageTitle.textContent = "Customer Chat Simulator";
        pageSubtitle.textContent = "Test the Counselling Brain from a client's perspective";
        // Reset chat automatically when entering simulator to ensure a clean state
        resetChatSimulation();
      } else if (targetTab === 'session-logs') {
        pageTitle.textContent = "Session Archive";
        pageSubtitle.textContent = "Review historic automated customer resolutions";
        renderLogsList();
      } else if (targetTab === 'settings') {
        pageTitle.textContent = "AI Brain Configuration";
        pageSubtitle.textContent = "Adjust prompts, tone audits, and custom models";
      }
    });
  });

  // Pause/Resume Automation Button
  const toggleBtn = document.getElementById('toggle-agent-btn');
  const statusDot = document.querySelector('.status-dot');
  const statusText = document.querySelector('.status-text');
  
  toggleBtn.addEventListener('click', () => {
    automationActive = !automationActive;
    if (automationActive) {
      toggleBtn.innerHTML = "<span>Pause Automation</span>";
      toggleBtn.className = "btn btn-secondary";
      statusDot.className = "status-dot green";
      statusText.textContent = "AI Agent Active (Replacing Manual Work)";
    } else {
      toggleBtn.innerHTML = "<span>Resume Automation</span>";
      toggleBtn.className = "btn btn-primary";
      statusDot.className = "status-dot";
      statusDot.style.backgroundColor = "var(--color-text-muted)";
      statusDot.style.boxShadow = "none";
      statusText.textContent = "Automation Paused (Manual Mode Active)";
    }
  });
}

// DASHBOARD LOGIC
function initDashboard() {
  // Populate Activity Feed initially
  const feed = document.getElementById('activity-feed');
  feed.innerHTML = '';
  
  FEED_MESSAGES.forEach((msg, idx) => {
    const li = document.createElement('li');
    li.className = 'activity-item';
    
    // Add varying times in the past
    const minutesAgo = (idx + 1) * 3;
    
    li.innerHTML = `
      <span class="activity-badge-dot"></span>
      <div class="activity-content">
        <p>${msg.text}</p>
        <span class="activity-time">${minutesAgo} mins ago • Auto-Resolved</span>
      </div>
    `;
    feed.appendChild(li);
  });
}

function startActivityFeedTimer() {
  const feed = document.getElementById('activity-feed');
  const names = ["Liam", "Sophia", "Oliver", "Zoe", "Amelia", "Lucas", "Maya", "Ethan", "Charlotte", "Gabriel"];
  const goals = [
    { text: "AI addressed hydration concerns for <strong>{name}</strong> (designed 3-glass baseline daily).", topic: "hydration" },
    { text: "AI built workout consistency schedule for <strong>{name}</strong> (using the 20-minute gym trick).", topic: "fitness" },
    { text: "AI resolved morning fatigue issue for <strong>{name}</strong> (adjusted sleeping schedule window).", topic: "sleep" },
    { text: "AI stabilized stress levels for <strong>{name}</strong> (guided evening wind-down journaling).", topic: "stress" },
    { text: "AI structured daily habit anchors for <strong>{name}</strong> (connected movement to lunch trigger).", topic: "habits" }
  ];
  
  setInterval(() => {
    if (!automationActive || activeTab !== 'dashboard') return;
    
    const randomName = names[Math.floor(Math.random() * names.length)];
    const randomGoalObj = goals[Math.floor(Math.random() * goals.length)];
    const textHtml = randomGoalObj.text.replace("{name}", randomName);
    
    const li = document.createElement('li');
    li.className = 'activity-item';
    li.style.opacity = 0;
    li.style.transform = 'translateY(-10px)';
    li.style.transition = 'all 0.5s ease';
    
    li.innerHTML = `
      <span class="activity-badge-dot"></span>
      <div class="activity-content">
        <p>${textHtml}</p>
        <span class="activity-time">Just now • Auto-Resolved</span>
      </div>
    `;
    
    feed.insertBefore(li, feed.firstChild);
    
    // Animate item entry
    setTimeout(() => {
      li.style.opacity = 1;
      li.style.transform = 'translateY(0)';
    }, 50);
    
    // Prune list if too long
    if (feed.children.length > 8) {
      feed.removeChild(feed.lastChild);
    }
    
    // Update Dashboard Metrics Randomly to look live
    const sessionCountElement = document.querySelector('.metric-card:first-child h3');
    let currentSessions = parseInt(sessionCountElement.textContent);
    sessionCountElement.textContent = currentSessions + 1;
    
  }, 12000); // Trigger every 12 seconds
}

// CUSTOMER CHAT SIMULATOR LOGIC
function initChatSimulator() {
  const personaCards = document.querySelectorAll('.persona-card');
  const sendBtn = document.getElementById('send-msg-btn');
  const resetBtn = document.getElementById('reset-chat-btn');
  const chatInput = document.getElementById('chat-input');
  
  personaCards.forEach(card => {
    card.addEventListener('click', () => {
      personaCards.forEach(p => p.classList.remove('active'));
      card.classList.add('active');
      
      currentPersona = card.getAttribute('data-persona');
      resetChatSimulation();
    });
  });
  
  sendBtn.addEventListener('click', () => handleClientSend());
  
  chatInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleClientSend();
    }
  });
  
  resetBtn.addEventListener('click', () => resetChatSimulation());
  
  // Set initial screen
  resetChatSimulation();
}

function resetChatSimulation() {
  chatStage = 0;
  currentChatHistory = [];
  const container = document.getElementById('chat-messages-container');
  container.innerHTML = '';
  
  // Clear chips
  const chipsContainer = document.getElementById('suggestion-chips-container');
  chipsContainer.innerHTML = '';
  
  const script = SIMULATION_SCRIPTS[currentPersona];
  
  if (currentPersona === 'custom') {
    appendChatMessage('assistant', "Hello. I am your Counselling Brain assistant. Please tell me what challenge, habit, or routine you are looking to work on today, and we can explore it together.");
    renderSuggestionChips(script.suggestedReplies);
  } else {
    // Client states their initial issue
    appendChatMessage('client', script.initialMsg);
    
    // Show bot thinking, then asking the initial questions
    showBotTyping(() => {
      appendChatMessage('assistant', script.botResponses.questions);
      renderSuggestionChips(script.suggestedReplies);
      chatStage = 1;
    });
  }
}

function handleClientSend(customText = null) {
  const chatInput = document.getElementById('chat-input');
  const text = customText || chatInput.value.trim();
  if (!text) return;
  
  if (!customText) {
    chatInput.value = '';
  }
  
  // Add client message
  appendChatMessage('client', text);
  
  // Clear chips
  const chipsContainer = document.getElementById('suggestion-chips-container');
  chipsContainer.innerHTML = '';
  
  showBotTyping(() => {
    if (currentPersona === 'custom') {
      if (chatStage === 0) {
        // AI asks questions first
        appendChatMessage('assistant', "I understand you want to improve this area. To help me build a personalized plan for you:\n1. What does your current setup look like?\n2. What is the biggest hurdle preventing consistency?");
        renderSuggestionChips([
          "I have a busy desk job and feel depleted by evening.",
          "I want to make changes but tend to do too much at once.",
          "My sleep is poor, which ruins my motivation."
        ]);
        chatStage = 1;
      } else if (chatStage === 1) {
        // AI gives structured advice
        const responseText = generateMockStructuredAdvice(text);
        appendChatMessage('assistant', responseText);
        renderSuggestionChips([
          "This feels realistic, I will start with Step 1.",
          "What if I have an injury or feel pain doing this?",
          "Can you explain the recovery aspect more?"
        ]);
        chatStage = 2;
      } else {
        // AI responds to follow up
        const reply = handleFollowUpResponse(text);
        appendChatMessage('assistant', reply);
      }
    } else {
      // Preset personas
      const script = SIMULATION_SCRIPTS[currentPersona];
      if (chatStage === 1) {
        appendChatMessage('assistant', script.botResponses.advice);
        renderSuggestionChips([
          "This action plan is very practical. I'll focus on Step 1 first.",
          "What happens if I miss a day or feel too tired?",
          "What if I experience physical pain or dizziness?"
        ]);
        chatStage = 2;
      } else {
        // Follow up stage
        const reply = handleFollowUpResponse(text);
        appendChatMessage('assistant', reply);
      }
    }
  });
}

function generateMockStructuredAdvice(clientResponse) {
  // Simulates dynamic generation following the template
  return `<h3>Understanding</h3>I hear that you want to address this lifestyle adjustment, and your main challenge is managing energy levels alongside your routine. It is completely normal to struggle with this when constraints are high.\n\n<h3>Insight</h3>Often, we treat lifestyle changes as intense bursts of effort. When fatigue sets in, the friction of starting becomes too high. The root pattern here is attempting a change without adjusting our daily recovery and environment.\n\n<h3>Recommendation</h3>We want to establish **consistency over intensity**. Start with small, non-negotiable routines that fit into your day without draining your mental energy.\n\n<h3>Action Plan</h3>1. **Reduce the Friction**: Put your tools or triggers in plain sight (e.g. water bottle on desk, shoes by door).\n2. **The 2-Minute Rule**: Perform the new habit for just 2 minutes daily to cement the identity.\n3. **Protect Your Sleep**: Keep your screen away for 20 minutes before bed to allow nervous system down-regulation.\n\n<h3>Supportive Close</h3>You are fully capable of establishing this, one small step at a time. Let's start with Step 1. Does that feel manageable for you this week?`;
}

function handleFollowUpResponse(inputText) {
  const query = inputText.toLowerCase();
  
  // Safety rule check
  if (query.includes('pain') || query.includes('dizzy') || query.includes('injury') || query.includes('hurt') || query.includes('doctor')) {
    return "<h3>Safety First</h3>Since you mentioned experiencing physical pain or injury, I must advise you to stop this activity immediately. Your safety is paramount. Please consult a qualified healthcare professional or doctor before resuming any physical routine. We can always adjust your routine to focus purely on sleep, hydration, or gentle breathing once you are cleared.";
  }
  
  if (query.includes('miss') || query.includes('tired') || query.includes('fail')) {
    return "<h3>Coaching Insight</h3>Missing a day is not a failure; it is just a normal variance in life. The gold standard rule is: **Never miss twice**. If you miss a day, make the next day's session just 2 minutes long. This keeps the neural pathways active without overwhelming you. Be gentle with yourself—consistency is a long game.";
  }
  
  return "<h3>Encouraging Close</h3>That is a wonderful observation. By taking the pressure off yourself and executing these micro-steps, you are training your brain to see wellness as an integrated part of your lifestyle rather than an extra chore. Let's stick with this primary step for the next 5 days. You've got this, and I'm right here to support your progress.";
}

function appendChatMessage(sender, text) {
  const container = document.getElementById('chat-messages-container');
  const row = document.createElement('div');
  row.className = `msg-row ${sender}`;
  
  // Format text to handle HTML tags for structured output nicely
  const formattedText = text.replace(/\n/g, '<br>');
  
  row.innerHTML = `
    <div class="msg-wrapper">
      <div class="msg-bubble">
        ${sender === 'assistant' ? `<div class="structured-output">${formatStructuredHTML(formattedText)}</div>` : `<p>${formattedText}</p>`}
      </div>
      <span class="msg-meta">${sender === 'assistant' ? 'Counselling Brain (AI)' : 'Customer'} • ${new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
    </div>
  `;
  
  container.appendChild(row);
  container.scrollTop = container.scrollHeight;
  
  // Add to local history log
  currentChatHistory.push({ sender, text });
}

function formatStructuredHTML(text) {
  // If the text contains h3 markers, let's wrap those blocks in beautiful styled cards
  if (text.includes('<h3>')) {
    let html = text;
    // We replace the h3 tags and wrap their sections in divs with border-left styles
    const sections = [
      { tag: '<h3>Understanding</h3>', cls: 'understanding' },
      { tag: '<h3>Insight</h3>', cls: 'insight' },
      { tag: '<h3>Recommendation</h3>', cls: 'recommendation' },
      { tag: '<h3>Action Plan</h3>', cls: 'action-plan' },
      { tag: '<h3>Supportive Close</h3>', cls: 'supportive-close' },
      { tag: '<h3>Safety First</h3>', cls: 'recommendation' },
      { tag: '<h3>Coaching Insight</h3>', cls: 'insight' },
      { tag: '<h3>Encouraging Close</h3>', cls: 'supportive-close' }
    ];
    
    // Parse list items in Action Plan specifically if they exist as **Item**: Text
    html = html.replace(/\*\*(.*?)\*\*:/g, '<strong>$1</strong>:');
    html = html.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
    
    sections.forEach(sec => {
      if (html.includes(sec.tag)) {
        // We find the index of this tag and the next tag to isolate content
        const startIdx = html.indexOf(sec.tag);
        let endIdx = html.length;
        
        sections.forEach(nextSec => {
          if (nextSec.tag !== sec.tag && html.includes(nextSec.tag)) {
            const nextIdx = html.indexOf(nextSec.tag);
            if (nextIdx > startIdx && nextIdx < endIdx) {
              endIdx = nextIdx;
            }
          }
        });
        
        const sectionContent = html.substring(startIdx, endIdx);
        const contentWithoutTag = sectionContent.replace(sec.tag, '');
        
        let processedContent = contentWithoutTag;
        // Parse numbers into bullets in action plan
        if (sec.cls === 'action-plan') {
          const lines = contentWithoutTag.split('<br>');
          let listHtml = '<ul class="sec-list">';
          lines.forEach(l => {
            let line = l.trim();
            if (line.match(/^\d+\.\s/)) {
              line = line.replace(/^\d+\.\s/, '');
              listHtml += `<li>${line}</li>`;
            } else if (line) {
              listHtml += `<li>${line}</li>`;
            }
          });
          listHtml += '</ul>';
          processedContent = listHtml;
        }
        
        const sectionContainer = `<div class="structured-sec ${sec.cls}"><span class="sec-title">${sec.tag.replace(/<\/?h3>/g, '')}</span><p>${processedContent}</p></div>`;
        html = html.replace(sectionContent, sectionContainer);
      }
    });
    
    return html;
  }
  return `<p>${text}</p>`;
}

function showBotTyping(callback) {
  const container = document.getElementById('chat-messages-container');
  const row = document.createElement('div');
  row.className = 'msg-row assistant typing-row';
  
  row.innerHTML = `
    <div class="msg-wrapper">
      <div class="msg-bubble" style="padding: 10px 16px;">
        <div class="typing-indicator">
          <div class="typing-dot"></div>
          <div class="typing-dot"></div>
          <div class="typing-dot"></div>
        </div>
      </div>
    </div>
  `;
  
  container.appendChild(row);
  container.scrollTop = container.scrollHeight;
  
  // Simulate delay
  setTimeout(() => {
    row.remove();
    callback();
  }, 1200 + Math.random() * 800);
}

function renderSuggestionChips(chips) {
  const chipsContainer = document.getElementById('suggestion-chips-container');
  chipsContainer.innerHTML = '';
  
  if (!chips) return;
  
  chips.forEach(text => {
    const button = document.createElement('button');
    button.className = 'chip';
    button.textContent = text;
    button.addEventListener('click', () => handleClientSend(text));
    chipsContainer.appendChild(button);
  });
}

// SESSION LOGS LOGIC
function initSessionLogs() {
  const searchInput = document.getElementById('logs-search');
  searchInput.addEventListener('input', () => {
    renderLogsList(searchInput.value.trim());
  });
  
  renderLogsList();
}

function renderLogsList(query = '') {
  const list = document.getElementById('logs-list');
  list.innerHTML = '';
  
  const filteredLogs = savedLogs.filter(log => {
    const q = query.toLowerCase();
    return log.client.toLowerCase().includes(q) || log.topic.toLowerCase().includes(q) || log.tag.toLowerCase().includes(q);
  });
  
  if (filteredLogs.length === 0) {
    list.innerHTML = '<div style="padding: 24px; text-align: center; color: var(--color-text-muted);">No sessions found</div>';
    return;
  }
  
  filteredLogs.forEach(log => {
    const div = document.createElement('div');
    div.className = 'log-row-item';
    div.setAttribute('data-id', log.id);
    
    // Get last client message preview
    const clientMsgs = log.messages.filter(m => m.sender === 'client');
    const lastMsg = clientMsgs.length > 0 ? clientMsgs[clientMsgs.length - 1].text : 'Start of chat...';
    
    div.innerHTML = `
      <div class="log-row-header">
        <h4>${log.client}</h4>
        <span class="log-row-meta">${log.date}</span>
      </div>
      <div class="log-preview">${lastMsg}</div>
      <div class="log-tags-row">
        <span class="tag ${log.tagClass}">${log.tag}</span>
        <span class="log-score">Score: ${log.rating}</span>
      </div>
    `;
    
    div.addEventListener('click', () => {
      document.querySelectorAll('.log-row-item').forEach(r => r.classList.remove('active'));
      div.classList.add('active');
      displayLogDetail(log);
    });
    
    list.appendChild(div);
  });
}

function displayLogDetail(log) {
  const viewer = document.getElementById('log-detail-viewer');
  viewer.innerHTML = '';
  
  const header = document.createElement('div');
  header.className = 'log-details-header';
  header.innerHTML = `
    <div>
      <h3>Session: ${log.client}</h3>
      <p>Topic: <strong>${log.topic}</strong> • Duration: ${log.duration} • Auto-Resolved</p>
    </div>
    <div>
      <span class="tag ${log.tagClass}">${log.tag}</span>
    </div>
  `;
  
  const scrollArea = document.createElement('div');
  scrollArea.className = 'log-details-scroll';
  
  log.messages.forEach(msg => {
    const msgDiv = document.createElement('div');
    msgDiv.className = `static-msg ${msg.sender}`;
    
    const formattedText = msg.text.replace(/\n/g, '<br>');
    
    msgDiv.innerHTML = `
      <span class="static-msg-header">${msg.sender === 'assistant' ? 'Counselling Brain' : 'Client'}</span>
      ${msg.sender === 'assistant' ? `<div class="structured-output">${formatStructuredHTML(formattedText)}</div>` : `<p>${formattedText}</p>`}
    `;
    scrollArea.appendChild(msgDiv);
  });
  
  viewer.appendChild(header);
  viewer.appendChild(scrollArea);
}

// CONFIGURATION / PROMPT SETTINGS LOGIC
function initSettings() {
  const editor = document.getElementById('system-prompt-editor');
  const presetBtns = document.querySelectorAll('.preset-buttons .btn');
  const saveBtn = document.getElementById('save-prompt-btn');
  const resetBtn = document.getElementById('reset-prompt-btn');
  const activeBadge = document.getElementById('active-personality-badge');
  
  // Set initial value
  editor.value = customUserPrompt;
  
  presetBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      presetBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      
      const presetName = btn.getAttribute('data-preset');
      editor.value = PROMPT_PRESETS[presetName] || PROMPT_PRESETS.premium;
    });
  });
  
  saveBtn.addEventListener('click', () => {
    customUserPrompt = editor.value;
    
    // Apply changes visual feedback
    saveBtn.textContent = "Saved & Applied!";
    saveBtn.className = "btn btn-primary";
    
    // Update badge in simulator
    const activePresetBtn = document.querySelector('.preset-buttons .btn.active');
    if (activePresetBtn) {
      activeBadge.textContent = activePresetBtn.textContent;
    } else {
      activeBadge.textContent = "Custom Prompt";
    }
    
    setTimeout(() => {
      saveBtn.textContent = "Save & Apply Changes";
    }, 2000);
  });
  
  resetBtn.addEventListener('click', () => {
    editor.value = PROMPT_PRESETS.premium;
    presetBtns.forEach(b => b.classList.remove('active'));
    document.querySelector('[data-preset="premium"]').classList.add('active');
    customUserPrompt = PROMPT_PRESETS.premium;
    activeBadge.textContent = "Luxury Premium Counselling";
  });
}
